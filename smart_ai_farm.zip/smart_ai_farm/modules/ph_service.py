# ============================================
# 🧪 PH SERVICE (FIXED)
# ============================================

def get_ph(location, soil_type):

    soil_ph_ranges = {
        "Black": 7.2,
        "Red": 6.2,
        "Alluvial": 7.0,
        "Loamy": 6.8,
        "Sandy": 6.5,
        "Clay": 6.7   # ✅ FIXED
    }

    ph = soil_ph_ranges.get(soil_type, 6.5)

    if location:
        location = location.lower()

        if "coastal" in location:
            ph -= 0.2
        elif "dry" in location:
            ph += 0.3

    return round(ph, 1)