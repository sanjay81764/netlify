import streamlit as st
from modules.weather_service import get_weather_by_location
from modules.ai_service import generate_response
from modules.ph_service import get_ph

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet


# ============================================
# 🌱 CROP PREDICTION (FINAL)
# ============================================

def predict_crop(location, soil_type=None, ph=None):

    # 🌐 Get selected language
    language = st.session_state.get("language", "English")

    # 🌦 Get weather
    weather = get_weather_by_location(location)

    if "error" in weather:
        return {"error": weather["error"]}

    temperature = weather["temperature"]
    humidity = weather["humidity"]
    wind_speed = weather["wind_speed"]
    soil_moisture = weather["soil_moisture"]

    # 🧪 Get pH if not provided
    if ph is None:
        ph = get_ph(location, soil_type)

    # ============================================
    # 🧠 AI PROMPT
    # ============================================

    prompt = f"""
You are an expert agriculture advisor.

IMPORTANT:
- Respond ONLY in {language}
- Keep explanation simple for farmers

Return STRICTLY in this format:

BEST_CROP:
Name:
Type:
Yield:
Reason:

COMPARISON:
- Crop1 vs Crop2: short comparison
- Crop1 vs Crop3: short comparison

TOP_CROPS:
1.
2.
3.
4.
5.

Conditions:
Location: {location}
Temperature: {temperature}
Humidity: {humidity}
Wind Speed: {wind_speed}
Soil Moisture: {soil_moisture}
Soil Type: {soil_type}
Soil pH: {ph}
"""

    # ============================================
    # 🤖 AI RESPONSE
    # ============================================

    try:
        ai_result = generate_response(prompt)

        if not ai_result:
            return {"error": "No response from AI"}

    except Exception as e:
        return {"error": str(e)}

    # ============================================
    # 📊 FORMATTED OUTPUT
    # ============================================

    formatted_output = f"""
📍 Location: {location}

🌡 Temp: {temperature}°C | 💧 Humidity: {humidity}%
🌬 Wind: {wind_speed} m/s | 🌱 Soil Moisture: {soil_moisture}
🧪 pH: {ph}

----------------------------------------

{ai_result}

----------------------------------------
"""

    return {
        "formatted_output": formatted_output,
        "weather": weather,
        "ph": ph,
        "ai_result": ai_result
    }


# ============================================
# 📄 PDF GENERATION
# ============================================

def generate_pdf_report(filename, location, weather, soil_type, ph, ai_result):

    doc = SimpleDocTemplate(filename)
    styles = getSampleStyleSheet()

    content = []

    content.append(Paragraph("Crop Recommendation Report", styles['Title']))
    content.append(Spacer(1, 12))

    content.append(Paragraph(f"Location: {location}", styles['Normal']))
    content.append(Spacer(1, 10))

    content.append(Paragraph("Weather:", styles['Heading2']))
    content.append(Paragraph(f"Temp: {weather['temperature']}°C", styles['Normal']))
    content.append(Paragraph(f"Humidity: {weather['humidity']}%", styles['Normal']))
    content.append(Spacer(1, 10))

    content.append(Paragraph("Recommendation:", styles['Heading2']))
    content.append(Paragraph(ai_result.replace("\n", "<br/>"), styles['Normal']))

    doc.build(content)

    return filename