import streamlit as st
from modules.ai_service import generate_image_response


# ============================================
# 🦠 DISEASE DETECTION (FINAL)
# ============================================

def detect_disease_from_image(image_bytes, crop_name=None):
    """
    Analyze plant leaf image and return detailed disease report
    """

    # ❌ Safety check
    if not image_bytes:
        return "❌ No image provided."

    # 🌐 Get selected language
    language = st.session_state.get("language", "English")

    # 🌱 Optional crop info
    crop_info = f"Crop: {crop_name}" if crop_name else ""

    # ============================================
    # 🧠 AI PROMPT
    # ============================================

    prompt = f"""
You are an expert plant pathologist.

Analyze the given plant leaf image carefully.

{crop_info}

IMPORTANT:
- Respond ONLY in {language}
- Keep explanation simple for farmers

Provide detailed report in this format:

🌿 Disease Name:
🧪 Confidence Level:

🔍 Observations:
- (spots, color change, fungus, damage)

🦠 Cause:

💊 Treatment:
- Organic:
- Chemical:

🌱 Recommended Fertilizer:

🛡️ Prevention Tips:

Instructions:
- Be accurate based on visible symptoms
- If unsure, say "Possible Disease"
"""

    # ============================================
    # 🤖 AI RESPONSE
    # ============================================

    try:
        response = generate_image_response(prompt, image_bytes)

        if not response:
            return "⚠️ No response from AI."

        return response.strip()

    except Exception as e:
        return f"⚠️ Disease Detection Error: {str(e)}"