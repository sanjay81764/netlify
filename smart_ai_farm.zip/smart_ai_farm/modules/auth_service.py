import sqlite3
import hashlib

DB_NAME = "smart_farm.db"


# ============================================
# 🔌 CONNECT DB
# ============================================

def get_connection():
    return sqlite3.connect(DB_NAME, check_same_thread=False)


# ============================================
# 🧱 CREATE USERS TABLE
# ============================================

def init_auth_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    conn.commit()
    conn.close()


# ============================================
# 🔐 HASH PASSWORD (SECURITY)
# ============================================

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


# ============================================
# 📝 REGISTER USER
# ============================================

def register_user(username, password):
    conn = get_connection()
    cursor = conn.cursor()

    hashed_password = hash_password(password)

    try:
        cursor.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (username, hashed_password)
        )
        conn.commit()
        return True
    except:
        return False
    finally:
        conn.close()


# ============================================
# 🔑 LOGIN USER
# ============================================

def login_user(username, password):
    conn = get_connection()
    cursor = conn.cursor()

    hashed_password = hash_password(password)

    cursor.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username, hashed_password)
    )

    user = cursor.fetchone()
    conn.close()

    return user