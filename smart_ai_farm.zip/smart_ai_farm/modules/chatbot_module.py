import streamlit as st
from modules.ai_service import generate_response


# ============================================
# 🤖 FARMER CHATBOT (FINAL)
# ============================================

def farmer_chatbot(user_question):

    # ❌ Empty check
    if not user_question:
        return "❌ Please enter a question."

    # 🌐 Get selected language
    language = st.session_state.get("language", "English")

    # ============================================
    # 🧠 AI PROMPT
    # ============================================

    prompt = f"""
You are an expert agriculture assistant helping farmers.

Farmer Question:
{user_question}

IMPORTANT:
- Respond ONLY in {language}
- Use simple language
- Keep answers short and clear
- Use bullet points if needed

Give practical farming advice.
"""

    # ============================================
    # 🤖 GENERATE RESPONSE
    # ============================================

    try:
        response = generate_response(prompt)

        if not response:
            return "⚠️ No response from AI."

        return response.strip()

    except Exception as e:
        return f"⚠️ Chatbot Error: {str(e)}"