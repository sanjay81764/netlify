import google.generativeai as genai

genai.configure(api_key="AIzaSyAX5mFSs8sBAjw5_M4ht35rnE3zy2ixv5Q")

model = genai.GenerativeModel("models/gemini-2.0-flash-exp-image-generation")

def generate_image_response(prompt, image_bytes):

    try:
        response = model.generate_content(
            [
                prompt,
                {
                    "mime_type": "image/png",  # works for most images
                    "data": image_bytes
                }
            ]
        )

        return response.text

    except Exception as e:
        return f"AI Error: {str(e)}"