from modules.weather_service import get_weather_by_location
from modules.ph_service import get_ph as estimate_ph
from modules.market_module import get_market_forecast
from modules.ai_service import generate_response
import sqlite3


# ============================================
# 💾 DATABASE SETUP
# ============================================

def init_digital_twin_db():
    conn = sqlite3.connect("smart_farm.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS digital_twin_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        crop TEXT,
        location TEXT,
        area REAL,
        yield REAL,
        profit REAL
    )
    """)

    conn.commit()
    conn.close()


# ============================================
# 💾 SAVE HISTORY
# ============================================

def save_simulation(crop, location, area, yield_val, profit):
    conn = sqlite3.connect("smart_farm.db")
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO digital_twin_history (crop, location, area, yield, profit) VALUES (?, ?, ?, ?, ?)",
        (crop, location, area, yield_val, profit)
    )

    conn.commit()
    conn.close()


# ============================================
# 🌾 SIMULATION
# ============================================

def simulate_farm(crop, location, area, soil_type=None):

    weather = get_weather_by_location(location)

    if not weather:
        temperature = 30
        humidity = 70
        soil_moisture = 0.2
    else:
        temperature = weather.get("temperature", 30)
        humidity = weather.get("humidity", 70)
        soil_moisture = weather.get("soil_moisture", 0.2)

    ph = estimate_ph(location, soil_type)

    yield_estimate = area * (2 + soil_moisture * 10)

    if temperature > 35:
        risk = "High 🔴"
    elif temperature > 30:
        risk = "Moderate 🟠"
    else:
        risk = "Low 🟢"

    water = "High 💧" if soil_moisture < 0.2 else "Normal 💧"

    # ✅ MARKET FIX
    market = get_market_forecast(crop, location)

    price = market.get("current_price", 2000)

    profit = yield_estimate * price

    try:
        ai = generate_response(f"Give short farming advice for {crop} in {location}")
    except:
        ai = ""

    if not ai or "error" in str(ai).lower():
        ai = "Maintain irrigation, monitor temperature, and use balanced fertilizers."

    save_simulation(crop, location, area, yield_estimate, profit)

    formatted_output = f"""
🌾 DIGITAL TWIN REPORT

📍 Location: {location}
🌾 Crop: {crop}

🌡 Temperature: {temperature} °C
💧 Humidity: {humidity} %
🌱 Soil Moisture: {soil_moisture}
🧪 pH: {ph}

----------------------------------------

🌾 Yield: {round(yield_estimate, 2)} tons
⚠ Risk: {risk}
💧 Water: {water}

💰 Market Price: ₹{price}
💰 Profit: ₹{round(profit, 2)}

----------------------------------------

🤖 Insights:
{ai}
"""

    return {
        "yield": round(yield_estimate, 2),
        "risk": risk,
        "water": water,
        "profit": round(profit, 2),
        "price": price,
        "ai": ai,
        "formatted_output": formatted_output
    }


# ============================================
# ⚔️ COMPARE CROPS (FINAL)
# ============================================

def compare_crops(crop1, crop2, location, area):

    result1 = simulate_farm(crop1, location, area)
    result2 = simulate_farm(crop2, location, area)

    return {
        "crop1_name": crop1,
        "crop2_name": crop2,
        "crop1": result1,
        "crop2": result2
    }