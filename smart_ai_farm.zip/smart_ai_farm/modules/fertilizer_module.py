from modules.ai_service import generate_response
from modules.language_service import add_language_instruction

# ============================================
# 🌿 FERTILIZER PLAN (FINAL)
# ============================================

def get_fertilizer_plan(crop, location, area):

    # ============================================
    # 🧠 AI PROMPT
    # ============================================

    prompt = f"""
You are an agriculture expert.

Give fertilizer plan for {crop} in {location}.

Include:
1. Stage-wise fertilizer
2. Dosage per acre
3. Simple farmer advice
"""

    # 🌐 Apply language (IMPORTANT)
    prompt = add_language_instruction(prompt)

    # ============================================
    # 🤖 AI RESPONSE
    # ============================================

    try:
        ai = generate_response(prompt)

    except Exception:
        ai = None

    # ============================================
    # 🔥 FALLBACK (IF AI FAILS)
    # ============================================

    if not ai or "error" in str(ai).lower():

        base_dosage = {
            "Seed": 20,
            "Growth": 40,
            "Flowering": 30,
            "Harvest": 10
        }

        stages = {}
        for stage, dose in base_dosage.items():
            stages[stage] = f"{dose * area} kg fertilizer"

        return {
            "stages": stages,
            "npk": {"N": 50, "P": 30, "K": 20},
            "advice": "Use balanced fertilizers and proper irrigation",
            "schedule": [
                "Day 1: Seed",
                "Day 15: Growth",
                "Day 30: Flowering",
                "Day 60: Harvest"
            ],
            "formatted_output": "Basic fertilizer plan applied"
        }

    # ============================================
    # ✅ SUCCESS OUTPUT
    # ============================================

    return {
        "stages": {
            "Seed Stage": f"{20 * area} kg compost",
            "Growth Stage": f"{40 * area} kg nitrogen fertilizer",
            "Flowering Stage": f"{30 * area} kg phosphorus fertilizer",
            "Harvest Stage": f"{10 * area} kg potassium fertilizer"
        },
        "npk": {"N": 60, "P": 25, "K": 15},
        "advice": ai,
        "schedule": [
            "🌱 Day 1: Seed Stage",
            "🌿 Day 15: Growth Stage",
            "🌸 Day 30: Flowering",
            "🌾 Day 60: Harvest"
        ],
        "formatted_output": ai
    }