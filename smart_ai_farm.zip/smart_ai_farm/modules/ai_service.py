from openai import OpenAI

# ✅ Direct API key (for testing)
client = OpenAI(
    api_key="sk-31ae628e3e8f49c7b8f43e64f8df030d",
    base_url="https://api.deepseek.com"
)


def generate_response(prompt):

    if not prompt:
        return "Invalid input"

    try:
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": "You are an agriculture expert."},
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content

    except Exception as e:
        return str(e)


def generate_image_response(prompt, image_bytes):

    return generate_response(prompt)  # fallback