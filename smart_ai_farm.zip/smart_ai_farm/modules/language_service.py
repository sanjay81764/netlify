# ============================================
# 🌐 LANGUAGE SERVICE (GLOBAL)
# ============================================

import streamlit as st


# ✅ Supported languages
SUPPORTED_LANGUAGES = {
    "English": "en",
    "Telugu": "te",
    "Hindi": "hi"
}


# ============================================
# 🌍 Initialize Language (Run once in app)
# ============================================

def initialize_language():
    if "language" not in st.session_state:
        st.session_state.language = "English"


# ============================================
# 🌐 Get Current Language Name
# ============================================

def get_language():
    return st.session_state.get("language", "English")


# ============================================
# 🔤 Get Language Code (for APIs if needed)
# ============================================

def get_language_code():
    language = get_language()
    return SUPPORTED_LANGUAGES.get(language, "en")


# ============================================
# 🧾 Create Prompt with Language Instruction
# ============================================

def add_language_instruction(prompt):
    language = get_language()

    return f"""
IMPORTANT:
Respond strictly in {language} language.
Use simple and clear words for farmers.

{prompt}
"""