import requests
from modules.ai_service import generate_response
from modules.language_service import add_language_instruction


# 🔑 YOUR API KEY
API_KEY = "579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b"


# ============================================
# 📡 REAL-TIME MANDI PRICE
# ============================================
def get_mandi_price(crop, state):

    url = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"

    params = {
        "api-key": API_KEY,
        "format": "json",
        "filters[commodity]": crop,
        "filters[state]": state,
        "limit": 1
    }

    try:
        response = requests.get(url, params=params)
        data = response.json()

        if "records" in data and len(data["records"]) > 0:
            record = data["records"][0]

            return {
                "mandi": record.get("market", "Unknown"),
                "price": int(record.get("modal_price", 0))
            }

        return {"error": "No data found"}

    except Exception as e:
        return {"error": str(e)}


# ============================================
# 📈 MARKET FORECAST (IMPORTANT FUNCTION)
# ============================================
def get_market_forecast(crop, location):

    mandi = get_mandi_price(crop, location)

    # 🔴 fallback if API fails
    if "error" in mandi:
        return {
            "mandi": "Demo Market",
            "current_price": 2000,
            "future_price": 2100,
            "trend": "📈 Increasing",
            "advice": "⚠️ No real data available. Try another crop/location."
        }

    current_price = mandi["price"]

    # 📈 simple prediction
    future_price = int(current_price * 1.05)

    trend = "📈 Increasing" if future_price > current_price else "📉 Decreasing"

    # 🧠 AI Advice
    prompt = f"""
Current price of {crop} in {location} is ₹{current_price}.
Expected future price: ₹{future_price}.

Should farmer sell or hold?
Give simple advice.
"""

    prompt = add_language_instruction(prompt)

    try:
        advice = generate_response(prompt)
    except:
        advice = "Market looks stable. Monitor prices."

    return {
        "mandi": mandi["mandi"],
        "current_price": current_price,
        "future_price": future_price,
        "trend": trend,
        "advice": advice
    }