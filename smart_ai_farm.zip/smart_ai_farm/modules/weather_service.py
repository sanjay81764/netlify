import requests


def get_coordinates(location):
    try:
        url = f"https://geocoding-api.open-meteo.com/v1/search?name={location}&count=1"
        response = requests.get(url, timeout=10)
        data = response.json()

        if "results" in data and len(data["results"]) > 0:
            return data["results"][0]["latitude"], data["results"][0]["longitude"]

        return None, None

    except:
        return None, None


def get_weather_by_location(location):
    lat, lon = get_coordinates(location)

    if lat is None:
        return {"error": "Invalid location"}

    try:
        url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={lat}&longitude={lon}"
            f"&current_weather=true"
            f"&hourly=relativehumidity_2m,soil_moisture_0_1cm"
        )

        data = requests.get(url, timeout=10).json()

        return {
            "temperature": data["current_weather"]["temperature"],
            "humidity": data["hourly"]["relativehumidity_2m"][0],
            "wind_speed": data["current_weather"]["windspeed"],
            "soil_moisture": data["hourly"]["soil_moisture_0_1cm"][0]
        }

    except:
        return {"error": "Weather fetch failed"}