import streamlit as st

# ===============================
# PAGE CONFIG (MUST BE FIRST)
# ===============================
st.set_page_config(
    page_title="Smart AI Farm",
    page_icon="🌾",
    layout="wide"
)

# ===============================
# DB INIT
# ===============================
from modules.auth_service import init_auth_db
init_auth_db()

# ===============================
# IMPORT UI MODULES
# ===============================
from ui.login_ui import login_ui
from ui.crop_ui import crop_ui
from ui.fertilizer_ui import fertilizer_ui
from ui import disease_ui
from ui.chatbot_ui import chatbot_ui
from ui.digital_twin_ui import digital_twin_ui
from ui.market_ui import market_ui
from ui.language_ui import language_selector_ui

# ===============================
# SESSION STATE
# ===============================
if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False

# ===============================
# LOGIN PAGE
# ===============================
if not st.session_state["logged_in"]:
    login_ui()
    st.stop()

# ===============================
# 🌐 LANGUAGE SELECTOR (ONLY HERE)
# ===============================
language_selector_ui()

# ===============================
# HEADER
# ===============================
st.title("🌾 Smart AI Farm")
st.caption("AI-powered agriculture assistant for smarter farming 🌱")

# ===============================
# SIDEBAR NAVIGATION
# ===============================
st.sidebar.title("📌 Navigation")

# Show logged-in user
st.sidebar.write(f"👤 {st.session_state.get('username', 'User')}")

menu = st.sidebar.radio(
    "Choose Feature",
    [
        "🏠 Home",
        "🌱 Crop Recommendation",
        "🌾 Fertilizer Recommendation",
        "🦠 Disease Detection",
        "🤖 Farmer Chatbot",
        "🌾 Digital Twin Simulation",
        "📈 Market Forecast"
    ]
)

# ===============================
# LOGOUT
# ===============================
if st.sidebar.button("🚪 Logout"):
    st.session_state["logged_in"] = False
    st.session_state["username"] = None
    st.rerun()

# ===============================
# ROUTING
# ===============================
st.divider()

# 🏠 HOME
if menu == "🏠 Home":

    st.subheader("🚀 Features Overview")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.info("🌱 Crop Recommendation\n\nGet best crops based on weather & soil")

    with col2:
        st.success("🌾 Fertilizer Plan\n\nStage-wise fertilizer guidance")

    with col3:
        st.warning("🦠 Disease Detection\n\nUpload image & detect plant diseases")

    col4, col5, col6 = st.columns(3)

    with col4:
        st.info("🤖 Chatbot\n\nAsk farming questions")

    with col5:
        st.success("🌾 Digital Twin\n\nSimulate farm conditions")

    with col6:
        st.warning("📈 Market Forecast\n\nPredict crop prices")

# 🌱 FEATURES
elif menu == "🌱 Crop Recommendation":
    crop_ui()

elif menu == "🌾 Fertilizer Recommendation":
    fertilizer_ui()

elif menu == "🦠 Disease Detection":
    disease_ui.show()

elif menu == "🤖 Farmer Chatbot":
    chatbot_ui()

elif menu == "🌾 Digital Twin Simulation":
    digital_twin_ui()

elif menu == "📈 Market Forecast":
    market_ui()