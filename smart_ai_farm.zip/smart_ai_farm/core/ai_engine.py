from google import genai

# 🔑 Put your Gemini API Key here
API_KEY = "AIzaSyCl1ozmVv8bG6oGZ--pAQjQ8fLKUaG3NF8"

client = genai.Client(api_key=API_KEY)

# Models fallback list
MODELS = [
    "models/gemini-2.5-flash-lite",
    "models/gemini-pro-latest",
    "models/gemini-flash-latest"
]

def generate_ai_response(prompt):
    """
    Sends prompt to Gemini AI
    Returns AI response text
    """

    for model in MODELS:
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text
        except:
            continue

    return "AI service is busy. Try again later."
