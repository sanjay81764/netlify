import streamlit as st
from modules.digital_twin_module import simulate_farm, compare_crops

def digital_twin_ui():

    st.title("🌾 Digital Twin Simulation")

    # ============================================
    # SINGLE SIMULATION
    # ============================================
    st.markdown("## 🔍 Single Simulation")

    crop = st.text_input("🌾 Crop")
    location = st.text_input("📍 Location")
    area = st.number_input("📏 Area (acres)", min_value=1, value=1)

    if st.button("🚀 Simulate", use_container_width=True):

        if not crop or not location:
            st.warning("Please enter all fields")
            return

        with st.spinner("Simulating farm..."):
            data = simulate_farm(crop, location, area)

        st.success("✅ Simulation Ready")

        st.metric("Yield", f"{data['yield']} tons")
        st.metric("Profit", f"₹{data['profit']}")
        st.metric("Risk", data["risk"])

        st.info(data["ai"])

        st.markdown("---")

    # ============================================
    # COMPARISON
    # ============================================
    st.markdown("## ⚔️ Compare Crops")

    col1, col2 = st.columns(2)

    with col1:
        crop1 = st.text_input("🌾 Crop 1")

    with col2:
        crop2 = st.text_input("🌾 Crop 2")

    location2 = st.text_input("📍 Location (Comparison)")
    area2 = st.number_input("📏 Area (Comparison)", min_value=1, value=1)

    if st.button("⚔️ Compare", use_container_width=True):

        if not crop1 or not crop2 or not location2:
            st.warning("Please fill all fields")
            return

        with st.spinner("Comparing crops..."):
            data = compare_crops(crop1, crop2, location2, area2)

        st.success("✅ Comparison Ready")

        c1, c2 = st.columns(2)

        # Crop 1
        with c1:
            st.subheader(f"🌾 {data['crop1_name']}")
            st.metric("Yield", f"{data['crop1']['yield']} tons")
            st.metric("Profit", f"₹{data['crop1']['profit']}")
            st.metric("Risk", data['crop1']['risk'])
            st.info(data['crop1']['ai'])

        # Crop 2
        with c2:
            st.subheader(f"🌾 {data['crop2_name']}")
            st.metric("Yield", f"{data['crop2']['yield']} tons")
            st.metric("Profit", f"₹{data['crop2']['profit']}")
            st.metric("Risk", data['crop2']['risk'])
            st.info(data['crop2']['ai'])

        # Winner
        st.markdown("---")

        if data["crop1"]["profit"] > data["crop2"]["profit"]:
            winner = data["crop1_name"]
        else:
            winner = data["crop2_name"]

        st.success(f"🏆 Best Crop: {winner}")