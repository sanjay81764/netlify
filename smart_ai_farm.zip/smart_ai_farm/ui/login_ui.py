import streamlit as st
from modules.auth_service import register_user, login_user


# ============================================
# 🔐 LOGIN / REGISTER UI (FINAL)
# ============================================

def login_ui():

    st.title("🔐 Smart AI Farm Login")

    st.caption("Access your personalized farming assistant 🌾")

    tab1, tab2 = st.tabs(["🔑 Login", "📝 Register"])

    # ===============================
    # 🔑 LOGIN
    # ===============================
    with tab1:

        st.subheader("Login to your account")

        username = st.text_input("👤 Username", key="login_user")
        password = st.text_input("🔒 Password", type="password", key="login_pass")

        if st.button("Login", use_container_width=True):

            if not username or not password:
                st.warning("Please enter both username and password")
                return

            user = login_user(username, password)

            if user:
                st.session_state["logged_in"] = True
                st.session_state["username"] = username
                st.success("✅ Login successful")

                st.rerun()
            else:
                st.error("❌ Invalid username or password")

    # ===============================
    # 📝 REGISTER
    # ===============================
    with tab2:

        st.subheader("Create a new account")

        new_user = st.text_input("👤 New Username", key="reg_user")
        new_pass = st.text_input("🔒 New Password", type="password", key="reg_pass")
        confirm_pass = st.text_input("🔒 Confirm Password", type="password", key="reg_confirm")

        if st.button("Register", use_container_width=True):

            # Validation
            if not new_user or not new_pass or not confirm_pass:
                st.warning("Please fill all fields")
                return

            if new_pass != confirm_pass:
                st.error("Passwords do not match")
                return

            if len(new_pass) < 4:
                st.warning("Password should be at least 4 characters")
                return

            success = register_user(new_user, new_pass)

            if success:
                st.success("✅ Registration successful! You can now login.")
            else:
                st.error("❌ Username already exists")