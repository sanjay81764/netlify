import streamlit as st
from modules.chatbot_module import farmer_chatbot


# ============================================
# 🌐 LANGUAGE TEXTS
# ============================================
def get_text(lang):

    if lang == "Telugu":
        return {
            "title": "రైతు AI సహాయకుడు",
            "caption": "మీ వ్యవసాయ ప్రశ్నలను అడగండి 🌾",
            "placeholder": "మీ ప్రశ్నను అడగండి...",
            "thinking": "ఆలోచిస్తోంది...",
            "clear": "చాట్ క్లియర్ చేయండి"
        }

    elif lang == "Hindi":
        return {
            "title": "किसान AI सहायक",
            "caption": "अपना कृषि प्रश्न पूछें 🌾",
            "placeholder": "अपना प्रश्न पूछें...",
            "thinking": "सोच रहा है...",
            "clear": "चैट साफ करें"
        }

    else:  # English
        return {
            "title": "Farmer AI Assistant",
            "caption": "Ask your agriculture-related questions 🌾",
            "placeholder": "Ask your question...",
            "thinking": "Thinking...",
            "clear": "Clear Chat"
        }


# ============================================
# 🤖 CHATBOT UI (FINAL)
# ============================================
def chatbot_ui():

    # 🌐 Get selected language
    lang = st.session_state.get("language", "English")
    text = get_text(lang)

    st.subheader(f"🤖 {text['title']}")
    st.caption(text["caption"])

    # ===============================
    # SESSION STATE
    # ===============================
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # ===============================
    # DISPLAY CHAT
    # ===============================
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    # ===============================
    # INPUT BOX
    # ===============================
    user_input = st.chat_input(text["placeholder"])

    if user_input:

        # User message
        st.session_state.messages.append({
            "role": "user",
            "content": user_input
        })

        with st.chat_message("user"):
            st.markdown(user_input)

        # Bot response
        with st.chat_message("assistant"):
            with st.spinner(text["thinking"]):
                response = farmer_chatbot(user_input)

            st.markdown(response)

        st.session_state.messages.append({
            "role": "assistant",
            "content": response
        })

    # ===============================
    # CLEAR CHAT
    # ===============================
    st.divider()

    col1, col2 = st.columns([1, 3])

    with col1:
        if st.button(f"🗑 {text['clear']}"):
            st.session_state.messages = []
            st.rerun()