import streamlit as st
from modules.fertilizer_module import get_fertilizer_plan
import pandas as pd


# ============================================
# 🌐 LANGUAGE TEXT FUNCTION
# ============================================
def get_text(lang):

    if lang == "Telugu":
        return {
            "title": "ఎరువు సిఫార్సు",
            "caption": "మెరుగైన దిగుబడికి పోషక ప్రణాళిక 🌱",
            "crop": "పంట",
            "location": "స్థానం",
            "area": "భూమి (ఎకరాలు)",
            "button": "ప్లాన్ రూపొందించండి",
            "loading": "ఎరువు ప్రణాళిక రూపొందుతోంది...",
            "stage": "దశల వారీ ప్రణాళిక",
            "chart": "పోషక చార్ట్",
            "schedule": "ఎరువు షెడ్యూల్",
            "advice": "నిపుణుల సలహా",
            "report": "పూర్తి నివేదిక"
        }

    elif lang == "Hindi":
        return {
            "title": "उर्वरक सिफारिश",
            "caption": "बेहतर उत्पादन के लिए पोषण योजना 🌱",
            "crop": "फसल",
            "location": "स्थान",
            "area": "क्षेत्र (एकड़)",
            "button": "योजना बनाएं",
            "loading": "उर्वरक योजना तैयार हो रही है...",
            "stage": "चरणवार योजना",
            "chart": "पोषक चार्ट",
            "schedule": "उर्वरक अनुसूची",
            "advice": "विशेषज्ञ सलाह",
            "report": "पूर्ण रिपोर्ट"
        }

    else:  # English
        return {
            "title": "Fertilizer Recommendation",
            "caption": "Smart nutrient planning for better yield 🌱",
            "crop": "Crop",
            "location": "Location",
            "area": "Area (acres)",
            "button": "Generate Plan",
            "loading": "Generating fertilizer plan...",
            "stage": "Stage-wise Plan",
            "chart": "Nutrient Chart",
            "schedule": "Fertilizer Schedule",
            "advice": "Expert Advice",
            "report": "Full Report"
        }


# ============================================
# 🌿 FERTILIZER UI (FINAL)
# ============================================
def fertilizer_ui():

    # 🌐 Get language
    lang = st.session_state.get("language", "English")
    text = get_text(lang)

    # ============================================
    # HEADER
    # ============================================
    st.title(f"🌾 {text['title']}")
    st.caption(text["caption"])

    st.markdown("---")

    # ============================================
    # INPUT
    # ============================================
    st.markdown("## 📥 Enter Details")

    col1, col2, col3 = st.columns(3)

    with col1:
        crop = st.text_input(f"🌾 {text['crop']}")

    with col2:
        location = st.text_input(f"📍 {text['location']}")

    with col3:
        area = st.number_input(f"📏 {text['area']}", min_value=1, value=1)

    st.markdown("---")

    # ============================================
    # BUTTON
    # ============================================
    if st.button(f"🚀 {text['button']}", use_container_width=True):

        if not crop or not location:
            st.warning("Please enter all fields")
            return

        with st.spinner(text["loading"]):
            data = get_fertilizer_plan(crop, location, area)

        st.success("✅ Done")

        # ============================================
        # 🌱 STAGES
        # ============================================
        st.markdown(f"## 🌱 {text['stage']}")

        for stage, value in data["stages"].items():
            st.markdown(f"""
            <div style="
                padding:15px;
                border-radius:12px;
                background:#f0f2f6;
                margin-bottom:10px;
            ">
                <b>{stage}</b><br>{value}
            </div>
            """, unsafe_allow_html=True)

        st.markdown("---")

        # ============================================
        # 📊 CHART
        # ============================================
        st.markdown(f"## 📊 {text['chart']}")

        df = pd.DataFrame({
            "Nutrient": ["N", "P", "K"],
            "Value": [
                data["npk"]["N"],
                data["npk"]["P"],
                data["npk"]["K"]
            ]
        })

        st.bar_chart(df.set_index("Nutrient"))

        st.markdown("---")

        # ============================================
        # 📅 SCHEDULE
        # ============================================
        st.markdown(f"## 📅 {text['schedule']}")

        for step in data["schedule"]:
            st.write("✔", step)

        st.markdown("---")

        # ============================================
        # 🤖 ADVICE
        # ============================================
        st.markdown(f"## 🤖 {text['advice']}")
        st.info(data["advice"])

        st.markdown("---")

        # ============================================
        # 📄 REPORT
        # ============================================
        with st.expander(f"📄 {text['report']}"):
            st.code(data["formatted_output"])