import streamlit as st

# ============================================
# 🌐 LANGUAGE SELECTOR UI (FINAL)
# ============================================

def language_selector_ui():

    # ✅ Set default language (only once)
    if "language" not in st.session_state:
        st.session_state["language"] = "English"

    # Sidebar UI
    st.sidebar.markdown("## 🌐 Language")

    selected_language = st.sidebar.selectbox(
        "Choose Language",
        ["English", "Telugu", "Hindi"],
        index=["English", "Telugu", "Hindi"].index(st.session_state["language"])
    )

    # ✅ Save globally
    st.session_state["language"] = selected_language

    return selected_language