import streamlit as st
from modules.disease_module import detect_disease_from_image


# ============================================
# 🌐 LANGUAGE TEXT FUNCTION
# ============================================
def get_text(lang):

    if lang == "Telugu":
        return {
            "title": "మొక్క వ్యాధి గుర్తింపు",
            "crop": "పంట పేరు నమోదు చేయండి (ఐచ్చికం)",
            "camera": "ఫోటో తీయండి",
            "upload": "చిత్రాన్ని అప్లోడ్ చేయండి",
            "detect": "వ్యాధిని గుర్తించండి",
            "analyzing": "చిత్రాన్ని విశ్లేషిస్తోంది...",
            "result": "ఫలితం"
        }

    elif lang == "Hindi":
        return {
            "title": "पौधों की बीमारी पहचान",
            "crop": "फसल का नाम दर्ज करें (वैकल्पिक)",
            "camera": "फोटो लें",
            "upload": "चित्र अपलोड करें",
            "detect": "बीमारी पहचानें",
            "analyzing": "छवि का विश्लेषण हो रहा है...",
            "result": "परिणाम"
        }

    else:  # English
        return {
            "title": "Plant Disease Detection",
            "crop": "Enter Crop Name (optional)",
            "camera": "Take a picture",
            "upload": "Upload image",
            "detect": "Detect Disease",
            "analyzing": "Analyzing...",
            "result": "Result"
        }


# ============================================
# 🦠 DISEASE UI (FINAL)
# ============================================
def show():

    # 🌐 Get selected language
    lang = st.session_state.get("language", "English")
    text = get_text(lang)

    st.title(f"🦠 {text['title']}")

    # 🌱 Crop input
    crop_name = st.text_input(f"🌱 {text['crop']}")

    # 📷 Tabs
    tab1, tab2 = st.tabs([f"📷 {text['camera']}", f"📁 {text['upload']}"])

    image_bytes = None

    # 📷 Camera
    with tab1:
        camera_image = st.camera_input(text["camera"])

        if camera_image:
            st.image(camera_image, use_column_width=True)
            image_bytes = camera_image.read()

    # 📁 Upload
    with tab2:
        uploaded_file = st.file_uploader(text["upload"], type=["jpg", "png", "jpeg"])

        if uploaded_file:
            st.image(uploaded_file, use_column_width=True)
            image_bytes = uploaded_file.read()

    # 🔍 Detect button
    if image_bytes and st.button(f"🔍 {text['detect']}"):

        with st.spinner(text["analyzing"]):
            result = detect_disease_from_image(image_bytes, crop_name)

        st.success(f"✅ {text['result']}")

        # 🎨 Styled Output
        st.markdown(f"""
        <div style="
            background: linear-gradient(135deg,#d4fc79,#96e6a1);
            padding:20px;
            border-radius:12px;
            font-size:16px;
            box-shadow:0 4px 10px rgba(0,0,0,0.2);
        ">
        <pre>{result}</pre>
        </div>
        """, unsafe_allow_html=True)