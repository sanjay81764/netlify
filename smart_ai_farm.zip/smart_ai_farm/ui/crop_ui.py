import streamlit as st
from modules.crop_module import predict_crop, generate_pdf_report
import pandas as pd


# ============================================
# 🌐 LANGUAGE TEXT FUNCTION
# ============================================
def get_text(lang):

    if lang == "Telugu":
        return {
            "title": "స్మార్ట్ పంట సిఫార్సు",
            "caption": "మెరుగైన దిగుబడికి AI సహాయం 🌱",
            "location": "స్థానం",
            "soil": "మట్టి రకం",
            "ph": "మట్టి pH (ఐచ్చికం)",
            "button": "విశ్లేషించండి",
            "loading": "పరిస్థితులను విశ్లేషిస్తోంది...",
            "weather": "వాతావరణం",
            "soil_details": "మట్టి వివరాలు",
            "result": "సిఫార్సు చేసిన పంటలు",
            "download": "రిపోర్ట్ డౌన్‌లోడ్ చేయండి"
        }

    elif lang == "Hindi":
        return {
            "title": "स्मार्ट फसल सिफारिश",
            "caption": "बेहतर उत्पादन के लिए AI सहायता 🌱",
            "location": "स्थान",
            "soil": "मिट्टी का प्रकार",
            "ph": "मिट्टी pH (वैकल्पिक)",
            "button": "विश्लेषण करें",
            "loading": "विश्लेषण किया जा रहा है...",
            "weather": "मौसम",
            "soil_details": "मिट्टी विवरण",
            "result": "अनुशंसित फसलें",
            "download": "रिपोर्ट डाउनलोड करें"
        }

    else:  # English
        return {
            "title": "Smart Crop Recommendation",
            "caption": "AI-powered farming assistant for better yield 🌱",
            "location": "Location",
            "soil": "Soil Type",
            "ph": "Soil pH (Optional)",
            "button": "Analyze Farm",
            "loading": "Analyzing farm conditions...",
            "weather": "Weather Overview",
            "soil_details": "Soil Details",
            "result": "Recommended Crops",
            "download": "Download Report"
        }


# ============================================
# 🌱 CROP UI (FINAL)
# ============================================
def crop_ui():

    # 🌐 Get selected language
    lang = st.session_state.get("language", "English")
    text = get_text(lang)

    # ============================================
    # HEADER
    # ============================================
    st.title(f"🌾 {text['title']}")
    st.caption(text["caption"])

    st.markdown("---")

    # ============================================
    # INPUT
    # ============================================
    st.markdown("## 📥 Enter Details")

    col1, col2 = st.columns(2)

    with col1:
        location = st.text_input(f"📍 {text['location']}", placeholder="e.g., Guntur")

    with col2:
        soil_type = st.selectbox(
            f"🌿 {text['soil']}",
            ["", "Loamy", "Clay", "Sandy"]
        )

    ph = st.text_input(f"🧪 {text['ph']}")

    if ph:
        try:
            ph = float(ph)
        except:
            st.error("Invalid pH value")
            return
    else:
        ph = None

    st.markdown("---")

    # ============================================
    # BUTTON
    # ============================================
    if st.button(f"🚀 {text['button']}", use_container_width=True):

        if not location:
            st.warning("Please enter location")
            return

        with st.spinner(text["loading"]):
            data = predict_crop(location, soil_type, ph)

        if "error" in data:
            st.error(data["error"])
            return

        st.success("✅ Done")

        # ============================================
        # WEATHER
        # ============================================
        st.markdown(f"## 🌦 {text['weather']}")

        col1, col2, col3, col4 = st.columns(4)

        col1.metric("🌡 Temp", f"{data['weather']['temperature']} °C")
        col2.metric("💧 Humidity", f"{data['weather']['humidity']} %")
        col3.metric("🌬 Wind", f"{data['weather']['wind_speed']} m/s")
        col4.metric("🌱 Soil", f"{data['weather']['soil_moisture']}")

        # Chart
        chart_data = pd.DataFrame({
            "Value": [
                data['weather']['temperature'],
                data['weather']['humidity'],
                data['weather']['wind_speed']
            ],
            "Parameter": ["Temp", "Humidity", "Wind"]
        })

        st.bar_chart(chart_data.set_index("Parameter"))

        st.markdown("---")

        # ============================================
        # SOIL
        # ============================================
        st.markdown(f"## 🌿 {text['soil_details']}")

        col1, col2 = st.columns(2)

        col1.metric("Soil Type", soil_type if soil_type else "N/A")
        col2.metric("pH", data["ph"])

        st.markdown("---")

        # ============================================
        # RESULT
        # ============================================
        st.markdown(f"## 🌾 {text['result']}")

        st.markdown(f"""
        <div style="
            background: linear-gradient(135deg,#d4fc79,#96e6a1);
            padding:20px;
            border-radius:12px;
            font-size:16px;
            box-shadow:0 4px 10px rgba(0,0,0,0.2);
        ">
        <pre>{data["ai_result"]}</pre>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")

        # ============================================
        # DOWNLOAD
        # ============================================
        pdf_file = "crop_report.pdf"

        generate_pdf_report(
            filename=pdf_file,
            location=location,
            weather=data["weather"],
            soil_type=soil_type,
            ph=data["ph"],
            ai_result=data["ai_result"]
        )

        with open(pdf_file, "rb") as file:
            st.download_button(
                label=f"📄 {text['download']}",
                data=file,
                file_name="crop_report.pdf",
                mime="application/pdf",
                use_container_width=True
            )