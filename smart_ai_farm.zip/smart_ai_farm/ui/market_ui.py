import streamlit as st
from modules.market_module import get_market_forecast
import pandas as pd
# ============================================
# 🌐 LANGUAGE TEXT
# ============================================
def get_text(lang):

    if lang == "Telugu":
        return {
            "title": "మార్కెట్ అంచనా",
            "caption": "పంట ధరలను ముందుగా తెలుసుకోండి 📈",
            "crop": "పంట",
            "location": "స్థానం",
            "button": "అంచనా చూడండి",
            "loading": "మార్కెట్ విశ్లేషిస్తోంది...",
            "price": "ప్రస్తుత ధర",
            "future": "భవిష్యత్ ధర",
            "trend": "ధోరణి",
            "advice": "సలహా"
        }

    elif lang == "Hindi":
        return {
            "title": "बाजार पूर्वानुमान",
            "caption": "फसल की कीमत पहले जानें 📈",
            "crop": "फसल",
            "location": "स्थान",
            "button": "पूर्वानुमान देखें",
            "loading": "विश्लेषण हो रहा है...",
            "price": "वर्तमान मूल्य",
            "future": "भविष्य मूल्य",
            "trend": "रुझान",
            "advice": "सलाह"
        }

    else:
        return {
            "title": "Market Forecast",
            "caption": "Predict crop prices 📈",
            "crop": "Crop",
            "location": "Location",
            "button": "Get Forecast",
            "loading": "Analyzing market...",
            "price": "Current Price",
            "future": "Future Price",
            "trend": "Trend",
            "advice": "Advice"
        }


# ============================================
# 📈 MARKET UI (FINAL)
# ============================================
def market_ui():

    lang = st.session_state.get("language", "English")
    text = get_text(lang)

    st.title(f"📈 {text['title']}")
    st.caption(text["caption"])

    st.markdown("---")

    col1, col2 = st.columns(2)

    with col1:
        crop = st.text_input(f"🌾 {text['crop']}")

    with col2:
        location = st.text_input(f"📍 {text['location']}")

    if st.button(f"🚀 {text['button']}", use_container_width=True):

        if not crop or not location:
            st.warning("Please enter all fields")
            return

        with st.spinner(text["loading"]):
            data = get_market_forecast(crop, location)

        st.success("✅ Done")

        # ============================================
        # 💰 METRICS
        # ============================================
        col1, col2, col3 = st.columns(3)

        col1.metric(text["price"], f"₹{data['current_price']}")
        col2.metric(text["future"], f"₹{data['future_price']}")
        col3.metric(text["trend"], data["trend"])

        # 🏪 Mandi Info
        st.write(f"🏪 Mandi: {data['mandi']}")

        st.markdown("---")

        # ============================================
        # 📊 CHART
        # ============================================
        df = pd.DataFrame({
            "Day": ["Today", "Future"],
            "Price": [data["current_price"], data["future_price"]]
        })

        st.line_chart(df.set_index("Day"))

        st.markdown("---")

        # ============================================
        # 🤖 ADVICE
        # ============================================
        st.markdown(f"## 🤖 {text['advice']}")
        st.info(data["advice"])